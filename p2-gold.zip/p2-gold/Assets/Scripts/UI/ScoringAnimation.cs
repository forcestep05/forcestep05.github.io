using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class ScoringAnimation : MonoBehaviour
{
    public float time_visible = 2f;
    private Text txt;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        txt = GetComponent<Text>();
        txt.color = new Color(1f, 1f, 1f, 0f);
        EventBus.Subscribe<ScoreEvent>(_OnScoreEvent);

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void _OnScoreEvent(ScoreEvent e)
    {
        txt.text = "";
        string i = "";
        if(e.bases != "")
        {
            i += e.bases;
        }
        if(e.score > 0)
        {
            i += "\n";
            i += "+" + e.score;
        }
        txt.text = i;
        StartCoroutine(DoVisible());
    }

    IEnumerator DoVisible()
    {
        float time_elapsed = 0f;
        txt.color = new Color(1f, 1f, 1f, 1f);
        while(time_elapsed < time_visible)
        {
            float l = time_elapsed / time_visible;
            float alpha = Mathf.Lerp(1f, 0f, l);
            txt.color = new Color(1f, 1f, 1f, alpha);
            time_elapsed += Time.deltaTime;
            yield return null;
        }
    }
}
