using UnityEngine;
using Assets;

public class UpgradePitch : Upgrade
{

    // Update is called once per frame
    void Update()
    {
        if (current_index == costs.Length)
        {
            cost.text = "MAX PITCHES!!!";
        }
        else
        {
            cost.text = costs[current_index].ToString();
        }
    }

    public void OnClick()
    {
        if (current_index == costs.Length || ScorePrint.score < costs[current_index] || !is_on_upgrade_screen)
        {
            return;
        }
        else
        {
            ScorePrint.score -= costs[current_index];
            EventBus.Publish<PitchUpgradeEvent>(new PitchUpgradeEvent());
            current_index++;

        }
    }
}

public class PitchUpgradeEvent { }
