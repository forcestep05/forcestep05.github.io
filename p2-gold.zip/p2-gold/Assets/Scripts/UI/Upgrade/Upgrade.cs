﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Assets
{
    public class Upgrade : MonoBehaviour
    {
        public int[] costs;
        public int current_index = 0;
        public Text cost;
        public bool is_on_upgrade_screen = false;
        // Use this for initialization
        void Start()
        {
            EventBus.Subscribe<GameOverEvent>(_OnGameOver);
            EventBus.Subscribe<UpgradeTransitionEvent>(_OnUpgradeTransition);
            EventBus.Subscribe<NextRoundEvent>(_OnNextRound);
        }


        void _OnGameOver(GameOverEvent e)
        {
            current_index = 0;
        }

        void _OnUpgradeTransition(UpgradeTransitionEvent e)
        {
            is_on_upgrade_screen = true;
        }

        void _OnNextRound(NextRoundEvent e)
        {
            is_on_upgrade_screen = false;
        }
    }
}