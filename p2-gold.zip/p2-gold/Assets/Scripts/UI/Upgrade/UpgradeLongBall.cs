using Assets;
using UnityEngine;

public class UpgradeLongBall : Upgrade
{

    // Update is called once per frame
    void Update()
    {
        if (current_index == costs.Length)
        {
            cost.text = "MAX!!!";
        }
        else
        {
            cost.text = costs[current_index].ToString();
        }
    }

    public void OnClick()
    {
        if (current_index == costs.Length || ScorePrint.score < costs[current_index] || !is_on_upgrade_screen)
        {
            return;
        }
        else
        {
            ScorePrint.score -= costs[current_index];
            EventBus.Publish(new LongBallUpgradeEvent());
            current_index++;

        }
    }
}
