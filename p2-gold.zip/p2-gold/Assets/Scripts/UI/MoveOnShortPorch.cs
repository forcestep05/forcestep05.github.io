using System.Collections;
using UnityEngine;

public class MoveOnShortPorch : MonoBehaviour
{
    public float[] positions;
    public float transition_time = 1f;
    private int current_index = -1;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        EventBus.Subscribe<ShortPorchUpgradeEvent>(_OnShortPorchUpgrade);
    }

    void _OnShortPorchUpgrade(ShortPorchUpgradeEvent e)
    {
        current_index++;
        StartCoroutine(DoMove());
        
    }

    IEnumerator DoMove()
    {
        float current_time = 0f;
        float starting_x = transform.position.x;
        while(current_time < transition_time)
        {
            float t = current_time / transition_time;
            float current_x = Mathf.Lerp(starting_x, positions[current_index], t);
            transform.position = new Vector3(current_x, 6f);
            current_time += Time.deltaTime;
            yield return null;
        }
        transform.position = new Vector3(positions[current_index], 6f);
    }
}
