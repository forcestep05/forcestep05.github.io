using UnityEngine;

public class NextRound : MonoBehaviour
{
    bool is_on_upgrade_screen = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        EventBus.Subscribe<UpgradeTransitionEvent>(_OnUpgradeTransition);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void _OnUpgradeTransition(UpgradeTransitionEvent e)
    {
        is_on_upgrade_screen = true;
    }

    public void OnClick()
    {
        if(is_on_upgrade_screen)
        {
            EventBus.Publish<NextRoundEvent>(new NextRoundEvent());
            is_on_upgrade_screen = false;
        }
    }
}

public class NextRoundEvent { }

