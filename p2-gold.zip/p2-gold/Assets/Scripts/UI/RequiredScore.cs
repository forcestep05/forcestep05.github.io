using UnityEngine;
using UnityEngine.UI;

public class RequiredScore : MonoBehaviour
{

    private int current_round = 0;
    public int[] required_scores;
    public GameObject roundText;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        EventBus.Subscribe<StartEvent>(_OnStartEvent);
        EventBus.Subscribe<EndRoundEvent>(_OnRoundEnd);
        EventBus.Subscribe<NextRoundEvent>(_OnNextRound);
    }

    // Update is called once per frame
    void Update()
    {
        GetComponent<Text>().text = required_scores[current_round].ToString();
        roundText.GetComponent<Text>().text = (current_round + 1).ToString();
    }

    void _OnStartEvent(StartEvent e)
    {
        current_round = 0;
    }

    void _OnRoundEnd(EndRoundEvent e)
    {
        if(ScorePrint.score >= required_scores[current_round] && current_round < required_scores.Length - 1)
        {
            // go to the upgrade UI (publish upgrade transition event)
            ScorePrint.score -= required_scores[current_round];
            EventBus.Publish<UpgradeTransitionEvent>(new UpgradeTransitionEvent());
        } else
        {
            EventBus.Publish<GameOverEvent>(new GameOverEvent());
            current_round = 0;
        }
    }

    void _OnNextRound(NextRoundEvent e)
    {
        current_round++;
    }
}

public class UpgradeTransitionEvent { }