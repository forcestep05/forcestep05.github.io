using System.Collections;
using UnityEngine;

public class MovePanelUI : MonoBehaviour
{
    public float movement_y = 0f;
    public float movement_x = 0f;
    public float transition_time = 1f;
    public float delay_time = 0f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        EventBus.Subscribe<StartEvent>(_OnGameStart);
        EventBus.Subscribe<RestartGameEvent>(_OnRestartGame);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void _OnGameStart(StartEvent e)
    {
        StartCoroutine(DoMove(new Vector3(movement_x, movement_y)));
    }

    private void _OnRestartGame(RestartGameEvent e)
    {
        StartCoroutine(DoMove(new Vector3(-1f * movement_x, -1f * movement_y)));
    }

    IEnumerator DoMove(Vector3 movement)
    {
        if(delay_time > 0)
        {
            yield return new WaitForSeconds(delay_time);
        }
        float current_time = 0f;
        Vector3 start_pos = transform.position;
        Vector3 end_pos = transform.position + movement;

        while (current_time < transition_time)
        {
            float t = current_time / transition_time;
            transform.position = Vector3.Lerp(start_pos, end_pos, t);
            current_time += Time.deltaTime;
            yield return null;
        }
        transform.position = end_pos;
    }
}
