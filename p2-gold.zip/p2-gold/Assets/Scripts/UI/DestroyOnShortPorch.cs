using UnityEngine;

public class DestroyOnShortPorch : MonoBehaviour
{
    public int index_to_delete = 1;
    int current_index = 0;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        EventBus.Subscribe<ShortPorchUpgradeEvent>(_OnShortPorchUpgrade);
    }

    void _OnShortPorchUpgrade(ShortPorchUpgradeEvent e)
    {
        current_index++;
        if(index_to_delete == current_index)
        {
            Destroy(gameObject);
        }
    }
}
