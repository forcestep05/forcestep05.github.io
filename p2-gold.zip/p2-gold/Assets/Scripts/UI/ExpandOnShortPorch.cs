using UnityEngine;

public class ExpandOnShortPorch : MonoBehaviour
{
    public float[] sizes;
    private int current_index = 0;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        EventBus.Subscribe<ShortPorchUpgradeEvent>(_OnShortPorchUpgrade);
    }
    void _OnShortPorchUpgrade(ShortPorchUpgradeEvent e)
    {
        transform.localScale = new Vector3(sizes[current_index], 1, 1);
        current_index++;
    }
}
