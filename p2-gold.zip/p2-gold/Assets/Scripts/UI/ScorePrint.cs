using UnityEngine;
using UnityEngine.UI;

public class ScorePrint : MonoBehaviour
{
    public static int score = 0;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        EventBus.Subscribe<ScoreEvent>(_OnScoreUpdate);
        EventBus.Subscribe<StartEvent>(_OnGameStart);
    }

    // Update is called once per frame
    void Update()
    {
        GetComponent<Text>().text = score.ToString();
    }

    void _OnScoreUpdate(ScoreEvent e)
    {
        score += e.score;
    }

    void _OnGameStart(StartEvent e)
    {
        score = 0;
    }
}
