using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PitchCount : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public static int pitches = 5;
    public static int current_pitches = 0;

    private int pitches_scored = 0;

    private bool end_round_on_score = false;
    void Start()
    {
        EventBus.Subscribe<ScoreEvent>(_OnScoreEvent);
        EventBus.Subscribe<PitchThrownEvent>(_OnPitchThrow);
        EventBus.Subscribe<StartEvent>(_OnStartGame);
        EventBus.Subscribe<NextRoundEvent>(_OnNextRound);
        EventBus.Subscribe<PitchUpgradeEvent>(_OnUpgradePitch);
    }

    // Update is called once per frame
    void Update()
    {
        GetComponent<Text>().text = current_pitches.ToString();
    }

    void _OnPitchThrow(PitchThrownEvent e)
    {
        current_pitches--;

    }
    void _OnScoreEvent(ScoreEvent e)
    {
        pitches_scored++;
        if(pitches_scored == pitches)
        {
            StartCoroutine(DoPause());
        }
    }

    void _OnStartGame(StartEvent e)
    {
        pitches = 5;
        current_pitches = pitches;
    }

    void _OnNextRound(NextRoundEvent e)
    {
        current_pitches = pitches;
        pitches_scored = 0;
    }

    void _OnUpgradePitch(PitchUpgradeEvent e)
    {
        pitches++;
    }

    IEnumerator DoPause()
    {
        yield return new WaitForSeconds(0.1f);
        EventBus.Publish<EndRoundEvent>(new EndRoundEvent());
    }
}

public class EndRoundEvent { }
