using System.Collections;
using UnityEngine;

public class OnBatSwing : MonoBehaviour
{
    public float bat_swing_time = 0.8f;
    public float bat_swing_time_back = 1f;
    private bool can_swing = true;

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Return) && can_swing)
        {
            StartCoroutine(DoSwing());
        }
    }

    IEnumerator DoSwing()
    {
        can_swing = false;
        Vector3 rotation = Vector3.zero;
        // Swing bat
        float current_time = 0f;
        Vector3 base_rotation = Vector3.zero;
        Vector3 final_rotation = new Vector3(0f, 0f, 200f);
        while(current_time < bat_swing_time)
        {
            float f = current_time / bat_swing_time;
            transform.rotation = Quaternion.Euler(Vector3.Lerp(base_rotation, final_rotation, f));
            current_time += Time.deltaTime;
            yield return null;
        }
        transform.rotation = Quaternion.Euler(final_rotation);
        current_time = 0f;
        // Bring back bat
        while (current_time < bat_swing_time_back)
        {
            float f = current_time / bat_swing_time_back;
            transform.rotation = Quaternion.Euler(Vector3.Lerp(final_rotation, base_rotation, f));
            current_time += Time.deltaTime;
            yield return null;
        }

        transform.rotation = Quaternion.identity;
        can_swing = true;
        
        yield return null;
    }
}
