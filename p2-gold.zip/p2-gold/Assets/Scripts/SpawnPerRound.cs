using System.Collections;
using UnityEngine;

public class SpawnPerRound : MonoBehaviour
{
    public float time_after_game_start = 1f;
    public float time_elapsed = 4f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, 0);
        EventBus.Subscribe<StartEvent>(_OnGameStart);
    }

    void _OnGameStart(StartEvent e)
    {
        StartCoroutine(DoFlash());
    }

    IEnumerator DoFlash()
    {
        float t = 0;
        while(t < time_after_game_start)
        {
            yield return null;
            t += Time.deltaTime;
        }
        t = 0;
        
        GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, 1);
        while (t < time_elapsed)
        {
            yield return null;
            t += Time.deltaTime;
        }
        GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, 0);
    }
}
