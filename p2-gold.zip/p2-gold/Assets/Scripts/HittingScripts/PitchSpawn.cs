using System.Collections;
using UnityEngine;

public class PitchSpawn : MonoBehaviour
{
    public float rotation_rev_time = 1f;
    public float pitch_launch_time = 0.3f;
    public float rebound_time = 1f;
    public float pitch_delay = 1f;
    public GameObject baseball;
    private bool is_game_started = false;
    public static bool can_pitch = true;

    
    void Start()
    {
        EventBus.Subscribe<StartEvent>(_OnStartGame);
        EventBus.Subscribe<RestartGameEvent>(_OnRestartGame);
        EventBus.Subscribe<UpgradeTransitionEvent>(_OnUpgradeTransition);
        EventBus.Subscribe<NextRoundEvent>(_OnNextRound);
    }
    // Update is called once per frame
    void Update()
    {
        if(is_game_started == false)
        {
            if(can_pitch)
            {
                StartCoroutine(DoPitch());
            }
        } else
        {
            if(can_pitch && Input.GetKeyDown(KeyCode.A))
            {
                EventBus.Publish<PitchThrownEvent>(new PitchThrownEvent());
                StartCoroutine(DoPitch());
            }
        }

    }

    IEnumerator DoPitch()
    {
        Debug.Log("pitching");
        can_pitch = false;
        Vector3 rotation = new Vector3(0f, 0f, -45f);
        float variance = Random.Range(-30f, 30f);
        bool spawned_pitch = false;
        Vector3 rev_rotation = Vector3.zero;
        float current_time = 0;
        // rev up machine
        while (current_time < rotation_rev_time)
        {
            float f = current_time / rotation_rev_time;
            transform.rotation = Quaternion.Euler(Vector3.Lerp(rotation, rev_rotation, f));
            current_time += Time.deltaTime;
            yield return null;
        }

        transform.rotation = Quaternion.Euler(rev_rotation);
        current_time = 0;
        Vector3 fire_rotation = new Vector3(0f, 0f, 230f);

        // move arm faster
        while (current_time < pitch_launch_time)
        {
            float f = current_time / pitch_launch_time;
            transform.rotation = Quaternion.Euler(Vector3.Lerp(rev_rotation, fire_rotation, f));
            current_time += Time.deltaTime;
            yield return null;

            // Fire pitch
            if (transform.rotation.eulerAngles.z >= 90 && !spawned_pitch)
            {
                fire_pitch();
                spawned_pitch = true;
            }
        }
        current_time = 0;
        // reset machine
        while (current_time < rebound_time)
        {
            float f = current_time / rebound_time;
            transform.rotation = Quaternion.Euler(Vector3.Lerp(fire_rotation, rotation,f));
            current_time += Time.deltaTime;
            yield return null;
        }

        yield return new WaitForSeconds(pitch_delay);
        transform.rotation = Quaternion.Euler(0f, 0f, -45f);
        set_pitch();

    }

    private void _OnStartGame(StartEvent e)
    {
        is_game_started = true;
    }

    private void _OnRestartGame(RestartGameEvent e)
    {
        StartCoroutine(DoRestart());
    }

    private void _OnUpgradeTransition(UpgradeTransitionEvent e)
    {
        can_pitch = false;
    }
    
    private void _OnNextRound(NextRoundEvent e)
    {
        can_pitch = true;
    }
    IEnumerator DoRestart()
    {
        yield return new WaitForSeconds(2f);
        is_game_started = false;
    }

    private void set_pitch() 
    { 
        if(PitchCount.current_pitches == 0 && is_game_started)
        {
            can_pitch = false;
        } else
        {
            can_pitch = true;
        }
    }
    private void fire_pitch()
    {
        float variance = Random.Range(-30f, 30f);
        float pitch_type = Random.Range(-1f, 1f);
        GameObject ball = GameObject.Instantiate(baseball, transform.position + (1.5f * Vector3.up), Quaternion.identity);

        if(pitch_type < 0f)
        {
            ball.GetComponent<Rigidbody>().AddForce(new Vector3(-1250f + variance, 0f));
        } else
        {
            ball.GetComponent<Rigidbody>().AddForce(new Vector3(-720f + variance, 250f));
        }

    }
}

public class PitchThrownEvent
{

}