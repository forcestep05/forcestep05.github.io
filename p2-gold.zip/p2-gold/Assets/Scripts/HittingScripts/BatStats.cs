using Unity.VisualScripting;
using UnityEngine;

public class BatStats : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public float[] min_velo;

    public float[] max_velo;

    public float[] sweet_spot_range;

    private int batting_level = 0;

    private int power_level = 0;

    void Start()
    {
        EventBus.Subscribe<PowerUpgradeEvent>(_OnPowerUpgrade);
        EventBus.Subscribe<BatUpgradeEvent>(_OnBatUpgrade);
        EventBus.Subscribe<GameOverEvent>(_OnGameOver);
    }

    public float CalculateVelocity(float angle)
    {
        float ret = min_velo[power_level];
        float norm_angle = angle - 90f;
        if(Mathf.Abs(norm_angle - 45f) < sweet_spot_range[batting_level])
        {
            ret = max_velo[power_level];
        } else
        {
            ret = Mathf.Lerp(min_velo[power_level], max_velo[power_level], 1f - (norm_angle / 55f));
        }
        return ret;
    }

    void _OnBatUpgrade(BatUpgradeEvent e)
    {
        if(batting_level < sweet_spot_range.Length - 1)
        {
            batting_level += 1;
        }
        
    }

    void _OnPowerUpgrade(PowerUpgradeEvent e)
    {
        if (power_level < max_velo.Length - 1)
        {
            power_level += 1;
        }
    }

    void _OnGameOver(GameOverEvent e)
    {
        batting_level = 0;
        power_level = 0;
    }

}

public class BatUpgradeEvent
{

}

public class PowerUpgradeEvent 
{ 

}
