using System.Collections;
using UnityEngine;

public class OnEnterScoreSpace : MonoBehaviour
{
    public int points = 100;
    public string bases;
    public bool is_homerun = false;
    private bool is_game_started = false;
    private bool long_ball_upgrade = false;

    private void Start()
    {
        EventBus.Subscribe<StartEvent>(_OnGameStart);
        EventBus.Subscribe<RestartGameEvent>(_OnRestartGame);
        if(is_homerun)
        {
            EventBus.Subscribe<LongBallUpgradeEvent>(_OnUpgradeLongBall);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(is_game_started && other.transform.name.Contains("Baseball"))
        {
            if (is_homerun && long_ball_upgrade)
            {
                EventBus.Publish<ScoreEvent>(new ScoreEvent(points + Mathf.FloorToInt(other.transform.position.x), bases));
            }
            else
            {
                EventBus.Publish<ScoreEvent>(new ScoreEvent(points, bases));
            }


            Destroy(other.gameObject);
        }

    }

    void _OnGameStart(StartEvent e)
    {
        is_game_started = true;
    }

    void _OnRestartGame(RestartGameEvent e)
    {
        is_game_started = false;
    }

    void _OnUpgradeLongBall(LongBallUpgradeEvent e)
    {
        long_ball_upgrade = true;
    }

}

public class ScoreEvent 
{
    public int score = 0;

    public string bases = "";
    public ScoreEvent(int score) { this.score = score; }
    public ScoreEvent(int score, string bases) { this.score = score; this.bases = bases; }
}

public class LongBallUpgradeEvent { }