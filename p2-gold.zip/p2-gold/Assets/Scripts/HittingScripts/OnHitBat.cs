using UnityEngine;

public class OnHitBat : MonoBehaviour
{
    private bool has_been_hit = false;
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.name == "bat" && !has_been_hit)
        {
            Transform bat_object = other.gameObject.transform.parent;
            Vector3 angle = bat_object.rotation.eulerAngles;
            Rigidbody rb = GetComponent<Rigidbody>();
            BatStats stats = other.gameObject.GetComponent<BatStats>();
            float contact_angle = angle.z;
            Vector3 new_dir = new Vector3(Mathf.Sin(Mathf.Deg2Rad * contact_angle), -1f * Mathf.Cos(Mathf.Deg2Rad * contact_angle));
            rb.linearVelocity = new_dir * stats.CalculateVelocity(contact_angle);
            Debug.Log(contact_angle);
            has_been_hit = true;
        }
    }
}
