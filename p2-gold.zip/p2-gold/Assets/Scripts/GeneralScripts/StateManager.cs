using UnityEngine;

public class StateManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public bool start_screen = true;

    void Start()
    {
        EventBus.Subscribe<GameOverEvent>(_OnGameOver);
    }

    private void Update()
    {
        if(start_screen && Input.GetKeyDown(KeyCode.Space))
        {
            EventBus.Publish<StartEvent>(new StartEvent());
            start_screen = false;
        }
        if(!start_screen && Input.GetKeyDown(KeyCode.Backspace))
        {
            EventBus.Publish<GameOverEvent>(new GameOverEvent());
        }
        if (!start_screen && Input.GetKeyDown(KeyCode.Equals))
        {
            ScorePrint.score += 9999;
        }
    }

    private void _OnGameOver(GameOverEvent e)
    {
        start_screen = true;
        EventBus.Publish<RestartGameEvent>(new RestartGameEvent());
    }
}

public class StartEvent {}

public class GameOverEvent {}

public class RestartGameEvent {}
