using UnityEngine;

public class DestroyOnGameStart : MonoBehaviour
{
    private Subscription<StartEvent> sub;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        sub = EventBus.Subscribe<StartEvent>(_OnGameStart);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void _OnGameStart(StartEvent e)
    {
        Destroy(gameObject);
    }

    private void OnDestroy()
    {
        EventBus.Unsubscribe<StartEvent>(sub);
    }
}
